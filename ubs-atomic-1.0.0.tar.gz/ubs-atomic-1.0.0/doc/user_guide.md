# ubs-atomic 用户指南

## 目录

1. [产品介绍](#产品介绍)
2. [快速上手](#快速上手)
3. [核心功能使用说明](#核心功能使用说明)
4. [配置选项详解](#配置选项详解)
5. [常见问题解答](#常见问题解答)
6. [附录](#附录)

---

## 1. 产品介绍

### 1.1 什么是 ubs-atomic

ubs-atomic 是一个基于共享内存的轻量级分布式基础组件，为您的应用程序提供高效的分布式原子服务能力。

### 1.2 主要功能

| 功能模块 | 功能描述 | 典型应用场景 |
|---------|---------|-------------|
| 分布式读写锁 | 支持多种锁模式（共享读/共享排他/独占写），适用于跨节点并发控制 | 元数据锁、事务并发控制 |
| 分布式互斥锁 | 轻量级排他锁，实现简单的互斥访问 | 资源保护、简单临界区控制 |
| 分布式自旋锁 | 基于 CAS 的高性能自旋锁 | 极短临界区、高频访问场景 |
| 分布式通信队列 | 基于共享内存的低延迟消息通道 | 节点间通知、事件投递 |
| 分布式事务资源 | 原子化的 64 位整数操作 | 计数器、状态位、全局序号分配 |

### 1.3 产品特点

- **高性能**: 基于共享内存实现，避免网络开销，实现极低延迟
- **轻量级**: C ABI 接口设计，适合 C/C++ 混合项目直接接入
- **可靠性**: 支持故障恢复、心跳检测、租约机制
- **灵活配置**: 提供丰富的配置选项，满足不同场景需求

### 1.4 适用场景

- 多进程/多节点场景下的共享资源互斥与读写协调
- 基于共享内存的低延迟消息传递与跨节点通知
- 分布式事务中的共享计数器、位点分配、状态同步

---

## 2. 快速上手

### 2.1 环境要求

- **操作系统**: Linux (推荐 CentOS 7.x 或更高版本)
- **硬件平台**: ARMv8-A (支持 LSE 原子指令)

### 2.2 安装步骤

#### 2.2.1 获取安装包

联系系统管理员获取最新版本的 RPM 安装包：
```
ubs-atomic-{version}-{release}.aarch64.rpm
```

#### 2.2.2 安装软件

```bash
# 使用 rpm 命令安装
rpm -ivh ubs-atomic-1.0.0-1.aarch64.rpm
```

#### 2.2.3 验证安装

```bash
# 检查库文件是否安装成功
ls -la /usr/lib64/libubs-atomic.so
```

### 2.3 配置共享内存

在使用 ubs-atomic 之前，需要确保已正确配置共享内存服务：

1. 确保 ubsmem 服务已启动
2. 配置共享内存段的权限
3. 记录共享内存的访问路径和大小

### 2.4 第一个应用示例

以下是一个简单的分布式事务资源使用示例：

```cpp
#include <cstdint>
#include <cstdio>
#include "ub_dist_tx_res.h"

// 声明共享内存中的计数器
alignas(8) uint64_t shm_counter = 0;

int main()
{
    uint64_t old_val = 0;
    uint64_t cur_val = 0;

    // 初始化计数器
    ub_dist_tx_res_init(&shm_counter);
    
    // 设置初始值为 100
    ub_dist_tx_res_set(&shm_counter, 100);
    
    // 原子加 1，返回旧值
    ub_dist_tx_res_fetch_add(&shm_counter, 1, &old_val);
    
    // 获取当前值
    ub_dist_tx_res_get(&shm_counter, &cur_val);

    printf("计数器: 旧值=%llu, 当前值=%llu\n", 
           (unsigned long long)old_val, 
           (unsigned long long)cur_val);
    
    return 0;
}
```

---

## 3. 核心功能使用说明

### 3.1 分布式读写锁

#### 3.1.1 功能概述

分布式读写锁支持三种锁模式，满足不同的并发访问需求：

| 锁模式 | 说明 | 兼容性 |
|-------|------|-------|
| S (共享读锁) | 多个节点可同时持有读锁 | 与 S/SX 兼容，与 X 互斥 |
| SX (共享排他锁) | 表示升级意图的锁 | 仅与 S 兼容，与 SX/X 互斥 |
| X (独占写锁) | 完全排他的写锁 | 与所有模式互斥 |

#### 3.1.2 使用流程

```
创建锁对象 → 获取锁 → 执行临界区操作 → 释放锁 → 销毁锁对象
```

#### 3.1.3 基本操作示例

```cpp
// 1. 定义身份标识（每个节点/线程唯一）
ub_location_t self{.tid = 1001, .node_id = 0};

// 2. 配置锁参数
ub_lock_config_t config{
    .lease_time = 60000,        // 租约时间 60 秒
    .heartbeat_timeout = 500    // 心跳超时 500 毫秒
};

// 3. 配置加锁策略
ub_lock_policy_t policy{
    .timeout_ts = 1000,              // 超时时间 1 秒
    .allow_delay_release = false,    // 不允许延迟释放
    .recursive = false               // 不允许递归加锁
};

// 4. 创建锁
ub_rw_lock_create(lock, &config, &self);

// 5. 获取写锁
if (ub_rw_lock_x_lock(lock, &policy, &self) == UB_LOCK_SUCCESS) {
    // 执行写操作
    // ...
    
    // 6. 释放写锁
    ub_rw_lock_x_unlock(lock, &policy, &self);
}

// 7. 销毁锁
ub_rw_lock_free(lock, &self);
```

### 3.2 分布式互斥锁

#### 3.2.1 功能概述

分布式互斥锁提供简单的排他访问能力，比读写锁更轻量级，适用于不需要区分读写的场景。

#### 3.2.2 使用示例

```cpp
// 初始化互斥锁
ub_mutex_lock_create(mutex, &config, &self);

// 获取锁
if (ub_mutex_lock(mutex, &policy, &self) == UB_LOCK_SUCCESS) {
    // 临界区操作
    // ...
    
    // 释放锁
    ub_mutex_unlock(mutex, &policy, &self);
}

// 释放资源
ub_mutex_lock_free(mutex, &self);
```

### 3.3 分布式自旋锁

#### 3.3.1 功能概述

分布式自旋锁基于 CAS 操作实现，适合极短临界区的高性能场景。在等待锁时不会阻塞线程，而是持续尝试获取。

#### 3.3.2 使用示例

```cpp
// 初始化自旋锁
ub_spin_lock_init(spin_lock);

// 获取锁（自旋等待）
ub_spin_lock(spin_lock, timeout_ms);

// 极短的临界区操作
// ...

// 释放锁
ub_spin_unlock(spin_lock);
```

### 3.4 分布式通信队列

#### 3.4.1 功能概述

分布式通信队列提供基于共享内存的低延迟消息传递能力，支持多节点、多优先级的消息投递。

#### 3.4.2 主要特点

- **同步/异步回调**: 支持同步和异步两种消息处理方式
- **流控机制**: 内置拥塞状态检测和流控策略
- **多优先级**: 支持多个优先级队列，确保高优先级消息优先处理

#### 3.4.3 使用示例

```cpp
// 消息处理回调函数
static void on_message(const message_t *msg, void *ctx) {
    // 处理接收到的消息
    printf("收到消息: %s\n", msg->body);
}

// 初始化通信队列
ub_comm_queue_init(&handle, &init_region, &ring_map, &config);

// 注册消息处理回调（同步模式）
ub_comm_queue_register_process_func(handle, 100, UB_FUNC_SYNC, on_message, nullptr);

// 构造并发送消息
message_t msg{};
msg.header.src_thread_id = 1;
msg.header.dest_node_id = 1;
msg.header.msg_type = 100;
msg.header.priority = 1;
msg.header.body_length = strlen("hello");
msg.body = "hello";

// 发送消息
ub_comm_queue_send(handle, &msg);

// 清理资源
ub_comm_queue_deinit(handle);
```

---

## 4. 配置选项详解

### 4.1 锁配置选项

#### 4.1.1 全局配置 (ub_lock_config_t)

| 配置项 | 类型 | 说明 | 默认值 |
|-------|------|------|-------|
| lease_time | uint32_t | 锁租约时间（毫秒） | 60000 |
| heartbeat_timeout | uint32_t | 心跳超时时间（毫秒） | 500 |

#### 4.1.2 加锁策略 (ub_lock_policy_t)

| 配置项 | 类型 | 说明 |
|-------|------|------|
| timeout_ts | uint32_t | 加锁超时时间（毫秒） |
| allow_delay_release | bool | 是否允许延迟释放 |
| recursive | bool | 是否允许递归加锁 |

### 4.2 通信队列配置

#### 4.2.1 队列配置 (ub_comm_conf_t)

| 配置项 | 类型 | 说明 |
|-------|------|------|
| cpu_id | int32_t | 绑核 CPU ID（-1 表示不绑核） |
| max_nodes | uint32_t | 最大节点数 |
| current_node_id | uint32_t | 当前节点 ID |
| num_rings | uint32_t | Ring 数量 |
| ring_descs | ub_ring_desc_t* | Ring 描述数组 |

#### 4.2.2 Ring 描述 (ub_ring_desc_t)

| 配置项 | 类型 | 说明 |
|-------|------|------|
| ring_capacity | uint32_t | Ring 容量（必须是 2 的幂） |
| max_msg_size | uint32_t | 单消息最大大小（字节） |
| priority | uint32_t | 优先级（从 1 开始） |

---

## 5. 常见问题解答

### Q1: 什么是共享内存？为什么需要它？

**A**: 共享内存是多个进程/节点可以共同访问的一块内存区域。相比网络通信，共享内存访问延迟更低、性能更高，特别适合需要高频数据交换的场景。

### Q2: 如何选择合适的锁类型？

**A**: 根据您的业务场景选择：
- **读多写少**: 使用分布式读写锁（S 模式）
- **简单排他**: 使用分布式互斥锁
- **极短临界区**: 使用分布式自旋锁

### Q3: 锁的租约时间应该设置多长？

**A**: 租约时间应大于您的临界区操作的最大执行时间。建议设置为预期最长执行时间的 2-3 倍，同时配合心跳机制检测节点存活状态。

### Q4: 什么是延迟释放？

**A**: 延迟释放是一种优化策略，当释放锁时不立即通知等待者，而是延迟一段时间后再通知。这可以减少频繁的跨节点通知开销，但会延迟锁的释放时机。适用于对实时性要求不高但追求高吞吐的场景。

### Q5: 通信队列的拥塞状态是什么意思？

**A**: 当队列中消息数量达到设定阈值（默认 80%）时，队列进入拥塞状态。此时发送消息会返回拥塞提示，但消息仍会被成功发送。建议根据此状态调整发送速率。

### Q6: 为什么需要 8 字节对齐？

**A**: 64 位原子操作要求内存地址必须是 8 字节对齐的，否则可能导致未定义行为或性能下降。

### Q7: 如何处理节点故障？

**A**: ubs-atomic 提供故障恢复接口：
- 分布式锁: 使用 `ub_rw_lock_recover` 接口按进程 ID 恢复异常持锁状态
- 通信队列: 支持节点就绪状态检查

### Q8: 性能如何？

**A**: 基于共享内存的实现，单次锁操作延迟通常在微秒级别，远低于网络通信方式。具体性能取决于：
- 锁竞争程度
- 临界区大小
- 硬件平台

### Q9: 是否支持跨平台？

**A**: 当前版本默认面向支持 LSE 原子指令的 ARMv8 平台。如需在其他平台使用，请联系技术支持调整编译选项。

### Q10: 如何获取技术支持？

**A**: 如遇技术问题，请收集以下信息后联系技术支持：
- 问题描述和复现步骤
- 相关日志文件
- 系统环境信息（操作系统版本、硬件平台等）
- 配置参数

---

## 6. 附录

### A. 返回码说明

#### A.1 锁操作返回码

| 返回码 | 含义 |
|-------|------|
| UB_LOCK_SUCCESS | 操作成功 |
| UB_LOCK_TIMEOUT | 等待超时 |
| UB_LOCK_CONFLICT | 锁冲突 |
| UB_LOCK_ERROR | 参数错误或内部异常 |

#### A.2 通信队列返回码

| 返回码 | 含义 |
|-------|------|
| UB_COMM_OK | 操作成功 |
| UB_COMM_SEND_CONGESTED | 消息发送成功，但队列拥塞 |
| UB_COMM_ERR_RING_FULL | Ring 已满，无法写入 |
| UB_COMM_ERROR | 操作失败 |

#### A.3 事务资源返回码

| 返回码 | 含义 |
|-------|------|
| UB_RES_OK | 操作成功 |
| UB_RES_ERROR | 操作失败 |

### B. 资源大小参考

| 资源类型 | 最小内存需求 |
|---------|------------|
| 分布式读写锁 | 640 字节 |
| 分布式互斥锁 | 384 字节 |
| 分布式自旋锁 | 64 字节 |
| 分布式事务资源 | 8 字节 |


---

*文档版本: 1.0*  
*最后更新: 2026年6月2日*
