/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.

 * rmrs is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *      http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#pragma once

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <unordered_map>
#include "ub_dist_lock.h"

#define UB_CACHELINE_SIZE 64
/* Maximum number of slots in the FIFO queue */
#define UB_MAX_CAPACITY 256
/* Maximum number of nodes participating in the distributed lock */
#define UB_MAX_NODES 16
/* Maximum number of nodes participating in the distributed lock */
#define LOCK_S_THRESHOLD 100
/* State machine for one waiter slot in the FIFO queue */
typedef uint32_t ub_wait_state_t;

#define UB_WAIT_EMPTY ((ub_wait_state_t)0u)    /* slot unused */
#define UB_WAIT_WRITING ((ub_wait_state_t)1u)  /* producer writing waiter data */
#define UB_WAIT_WAITING ((ub_wait_state_t)2u)  /* waiting for notification */
#define UB_WAIT_NOTIFIED ((ub_wait_state_t)3u) /* notified (ready to wake up) */
#define UB_WAIT_TIMEOUT ((ub_wait_state_t)4u)  /* timed out */

struct alignas(16) ub_waiter_t {
    std::atomic<uint32_t> seq; /* seq-based ring state machine */
    ub_lock_mode_t mode;       /* requested lock mode */
    ub_location_t location;    /* waiter identity */
};                             /* One entry in the wait queue ring buffer */

struct alignas(UB_CACHELINE_SIZE) ub_rw_lock {
    std::atomic<int32_t> lock_word;      /* core lock state machine */
    std::atomic<uint32_t> waiting_count; /* fast-path waiter indicator */
    uint8_t _pad_core[56];

    std::atomic<uint32_t> queue_head; /* wait queue head index */
    uint8_t _pad_qt[60];
    std::atomic<uint32_t> queue_tail; /* wait queue tail index */
    uint8_t _pad_qh[60];

    std::atomic<uint64_t> lock_owner_x;        /* exclusive lock owner */
    std::atomic<uint64_t> lock_owner_sx;       /* shared-exclusive owner */
    std::atomic<uint64_t> reserve_lock_owner;  /* delayed-release owner */
    std::atomic<uint32_t> sx_recursive;        /* number of recursive sx lock */
    std::atomic<uint32_t> x_recursive;         /* number of recursive x lock */
    std::atomic<int32_t> is_inited;            /* initialization flag */
    std::atomic<uint32_t> shared_owner_bitmap; /* bitmap of processes holding s locks */
    uint8_t _pad_misc[24];                     /* Fill remaining 24 bytes */

    ub_waiter_t wait_queue[UB_MAX_NODES];  /* FIFO wait queue */
    uintptr_t node_registry[UB_MAX_NODES]; /* UB lock table */
};

inline void cpu_relax()
{
#if defined(__aarch64__) || defined(__arm__)
    asm volatile("yield" ::: "memory"); // ARM hint, not OS yield
#else
    asm volatile("" ::: "memory");
#endif
}

namespace ublock {

constexpr int32_t UB_LOCK_OWNER_NODE_SHIFT = 32;
constexpr int32_t X_LOCK_DECR = 1 << 16;      // 65536
constexpr int32_t X_LOCK_HALF_DECR = 1 << 15; // 32768
constexpr uint32_t SPIN_WAIT_ROUNDS = 30;
constexpr uint64_t LOCK_INVALID_OWNER = static_cast<uint64_t>(255) << 32;

// Four 16-bit lanes: 14-bit reader count + X sentinel; lane0/1 high bits hold SX/X flags.
constexpr uint32_t LOCAL_LOCK_READER_LANES = 4;
constexpr uint32_t LOCAL_LOCK_READER_LANE_BITS = 16;
constexpr uint64_t LOCAL_LOCK_READER_COUNT_MASK = 0x3FFFu;
constexpr uint64_t LOCAL_LOCK_READER_SENTINEL = 0x4000u;
constexpr uint32_t LOCAL_LOCK_SX_LANE = 0;
constexpr uint64_t LOCAL_LOCK_SX_FLAG = 0x8000uLL;
constexpr uint64_t LOCAL_LOCK_X_FLAG = 0x8000uLL << LOCAL_LOCK_READER_LANE_BITS;

constexpr uint64_t make_local_lock_lane_mask(uint64_t lane_mask)
{
    uint64_t mask = 0;
    for (uint32_t i = 0; i < LOCAL_LOCK_READER_LANES; ++i) {
        mask |= lane_mask << (i * LOCAL_LOCK_READER_LANE_BITS);
    }
    return mask;
}

constexpr uint64_t LOCAL_LOCK_READER_SENTINEL_MASK = make_local_lock_lane_mask(LOCAL_LOCK_READER_SENTINEL);
constexpr uint64_t LOCAL_LOCK_X_STATE = LOCAL_LOCK_X_FLAG | LOCAL_LOCK_READER_SENTINEL_MASK;
static_assert((LOCAL_LOCK_READER_LANES & (LOCAL_LOCK_READER_LANES - 1u)) == 0,
              "reader lane count must be a power of two");

inline uint32_t local_lock_lane_for_tid(int32_t tid) noexcept
{
    return static_cast<uint32_t>(tid) & (LOCAL_LOCK_READER_LANES - 1u);
}

inline uint16_t local_lock_lane_value(uint64_t state, uint32_t lane) noexcept
{
    return static_cast<uint16_t>((state >> (lane * LOCAL_LOCK_READER_LANE_BITS)) & 0xFFFFu);
}

inline uint32_t local_lock_reader_count(uint64_t state) noexcept
{
    uint32_t count = 0;
    for (uint32_t lane = 0; lane < LOCAL_LOCK_READER_LANES; ++lane) {
        count += static_cast<uint32_t>(local_lock_lane_value(state, lane) & LOCAL_LOCK_READER_COUNT_MASK);
    }
    return count;
}

using steady_time_point = std::chrono::steady_clock::time_point;
// a lightweight cacheline padding wrapper for a single atomic
template <class T>
struct alignas(UB_CACHELINE_SIZE) CachelineAtomic {
    std::atomic<T> v;
    CachelineAtomic() noexcept = default;
    constexpr CachelineAtomic(T init) noexcept : v(init) {}
    CachelineAtomic(const CachelineAtomic &) = delete;
    CachelineAtomic &operator=(const CachelineAtomic &) = delete;
};

// Local-only mixed-width state: S/SX use lane operations, X uses whole-word CAS.
struct alignas(UB_CACHELINE_SIZE) LocalLockStateWord {
    LocalLockStateWord() noexcept = default;
    explicit constexpr LocalLockStateWord(uint64_t init) noexcept : word_(init) {}
    LocalLockStateWord(const LocalLockStateWord &) = delete;
    LocalLockStateWord &operator=(const LocalLockStateWord &) = delete;

    uint64_t load(std::memory_order order = std::memory_order_acquire) const noexcept
    {
        return __atomic_load_n(const_cast<uint64_t *>(&word_), atomic_order(order));
    }

    void store(uint64_t value, std::memory_order order = std::memory_order_release) noexcept
    {
        __atomic_store_n(&word_, value, atomic_order(order));
    }

    bool compare_exchange_weak(uint64_t &expected, uint64_t desired, std::memory_order success,
                               std::memory_order failure) noexcept
    {
        return __atomic_compare_exchange_n(&word_, &expected, desired, true, atomic_order(success),
                                           atomic_order(failure));
    }

    bool compare_exchange_lane_weak(uint32_t lane, uint16_t &expected, uint16_t desired, std::memory_order success,
                                    std::memory_order failure) noexcept
    {
        return __atomic_compare_exchange_n(lane_ptr(lane), &expected, desired, true, atomic_order(success),
                                           atomic_order(failure));
    }

    bool compare_exchange_lane_strong(uint32_t lane, uint16_t &expected, uint16_t desired, std::memory_order success,
                                      std::memory_order failure) noexcept
    {
        return __atomic_compare_exchange_n(lane_ptr(lane), &expected, desired, false, atomic_order(success),
                                           atomic_order(failure));
    }

    uint16_t fetch_and_lane(uint32_t lane, uint16_t mask, std::memory_order order) noexcept
    {
        return __atomic_fetch_and(lane_ptr(lane), mask, atomic_order(order));
    }

private:
    static int atomic_order(std::memory_order order) noexcept
    {
        switch (order) {
            case std::memory_order_relaxed:
                return __ATOMIC_RELAXED;
            case std::memory_order_consume:
            case std::memory_order_acquire:
                return __ATOMIC_ACQUIRE;
            case std::memory_order_release:
                return __ATOMIC_RELEASE;
            case std::memory_order_acq_rel:
                return __ATOMIC_ACQ_REL;
            case std::memory_order_seq_cst:
            default:
                return __ATOMIC_SEQ_CST;
        }
    }

    uint16_t *lane_ptr(uint32_t lane) noexcept
    {
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
        return reinterpret_cast<uint16_t *>(&word_) + (LOCAL_LOCK_READER_LANES - 1u - lane);
#else
        return reinterpret_cast<uint16_t *>(&word_) + lane;
#endif
    }

    alignas(sizeof(uint64_t)) uint64_t word_{0};
};

struct local_wait_ctx_t {
    std::mutex mtx;
    std::condition_variable cv;
    bool notified = false;

    bool wait(steady_time_point deadline)
    {
        std::unique_lock<std::mutex> lk(mtx);
        return cv.wait_until(lk, deadline, [&] { return notified; });
    }

    void notify()
    {
        std::lock_guard<std::mutex> lk(mtx);
        notified = true;
        cv.notify_one();
    }

    void reset()
    {
        std::lock_guard<std::mutex> lk(mtx);
        notified = false;
    }
};

class WaiterRegistry {
public:
    static WaiterRegistry &instance()
    {
        static WaiterRegistry inst;
        return inst;
    }
    // 注册：将 tid 映射到本地上下文
    void register_waiter(int32_t tid, local_wait_ctx_t *ctx)
    {
        std::unique_lock<std::shared_mutex> lock(map_mtx_);
        waiter_map_[tid] = ctx;
    }
    // 注销：等待结束或超时后移除
    void unregister_waiter(int32_t tid)
    {
        std::unique_lock<std::shared_mutex> lock(map_mtx_);
        waiter_map_.erase(tid);
    }
    // 查找并唤醒：根据 TID 找到上下文并唤醒
    // 返回 true 表示找到了本地线程并唤醒，false 表示该 TID 不在本地
    bool notify_local_waiter(int32_t tid)
    {
        std::shared_lock<std::shared_mutex> lock(map_mtx_);
        auto it = waiter_map_.find(tid);
        if (it != waiter_map_.end()) {
            // 找到了！唤醒它
            it->second->notify();
            return true;
        }
        return false;
    }

private:
    // 使用 shared_mutex 提高读并发 (Lookup频率高)
    std::shared_mutex map_mtx_;
    std::unordered_map<int32_t, local_wait_ctx_t *> waiter_map_;
};

class WaiterGuard {
public:
    WaiterGuard(int32_t tid, local_wait_ctx_t *ctx) : tid_(tid)
    {
        WaiterRegistry::instance().register_waiter(tid_, ctx);
    }

    ~WaiterGuard()
    {
        WaiterRegistry::instance().unregister_waiter(tid_);
    }

    // 禁止拷贝和移动，确保一一对应
    WaiterGuard(const WaiterGuard &) = delete;
    WaiterGuard &operator=(const WaiterGuard &) = delete;

private:
    int32_t tid_;
};

struct local_waiter_t {
    std::atomic<ub_wait_state_t> seq{UB_WAIT_EMPTY};
    ub_lock_mode_t mode{UB_LOCK_I};
    int32_t tid{0};
};

class LocalLock {
public:
    explicit LocalLock(ub_rw_lock_t *shm) : ub_lock_ptr_(shm)
    {
        init_();
    }
    ~LocalLock() = default;

    ub_lock_result_t lock_s(int32_t tid, steady_time_point deadline);
    ub_lock_result_t lock_sx(bool allow_recursive, int32_t tid, steady_time_point deadline);
    ub_lock_result_t lock_x(bool allow_recursive, int32_t tid, steady_time_point deadline);

    ub_lock_result_t unlock_s(int32_t tid);
    ub_lock_result_t unlock_sx(bool allow_recursive, int32_t tid);
    ub_lock_result_t unlock_x(bool allow_recursive, int32_t tid);

    ub_rw_lock_t *ub_lock_ptr_{nullptr}; // global lock virtual address

    void init_();
    // queue
    void create_wait_queue();
    ub_lock_result_t enqueue_waiter(ub_lock_mode_t mode, int32_t tid, uint32_t &out_ticket);
    ub_lock_result_t outqueue_waiter(local_waiter_t *&out);
    bool peek_head_waiting_mode_clean(ub_lock_mode_t &mode_out);
    void clean_timeout_waiter(uint32_t ticket);
    void clean_outqueue_waiter(uint32_t ticket);
    bool notify_one(local_waiter_t &w);
    void wake_after_unlock_exclusive(); // batch wake by rule
    void dequeue_and_notify_one();

    bool is_held();
    void end_remote_release();
    bool try_begin_remote_release();
    bool try_inc_global_ref();

    LocalLockStateWord lock_word{};
    CachelineAtomic<uint32_t> q_head{0};
    CachelineAtomic<uint32_t> q_tail{0};
    std::atomic<uint32_t> waiting_count{0};
    std::atomic<uint32_t> read_count{0};
    std::atomic<int32_t> lock_x_owner{0};
    std::atomic<int32_t> lock_sx_owner{0};
    std::atomic<uint32_t> x_recursive_{0};
    std::atomic<uint32_t> sx_recursive_{0};

    std::array<local_waiter_t, UB_MAX_CAPACITY> q{};

    std::atomic<ub_lock_mode_t> local_is_reserve_lock{UB_LOCK_I};
    std::atomic<bool> remote_release_in_progress_{false};
    std::atomic<bool> hold_global{false};

    enum GlobalState : int
    {
        GLOBAL_IDLE = 0,
        GLOBAL_PENDING = 1,
        GLOBAL_HELD = 2
    };
    std::atomic<int> global_state_{GLOBAL_IDLE};
    std::atomic<int32_t> global_read_ref_count_{0};
    std::mutex global_pending_mtx_;
    std::condition_variable global_pending_cv_;
};

struct LocalLockRegistry {
    std::unordered_map<ub_rw_lock_t *, std::shared_ptr<LocalLock>> map;
    mutable std::shared_mutex mtx;
};

inline LocalLockRegistry g_ll_registry;

std::shared_ptr<LocalLock> lookup_local_lock(ub_rw_lock_t *shm);
void register_local_lock(ub_rw_lock_t *shm, std::shared_ptr<LocalLock> ll);
std::shared_ptr<LocalLock> unregister_local_lock(ub_rw_lock_t *shm);

// NodeID + TID -> uint64_t
inline uint64_t make_global_owner(uint8_t node_id, int32_t tid)
{
    return (static_cast<uint64_t>(node_id) << 32) | static_cast<uint32_t>(tid);
}

} // namespace ublock
